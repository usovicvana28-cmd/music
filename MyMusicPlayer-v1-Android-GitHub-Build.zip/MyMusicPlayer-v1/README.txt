MY MUSIC PLAYER 1.0 — Android source project

Included in this version:
- First-launch folder selection using Android's system folder picker.
- Scanning of the selected folder and its subfolders.
- FLAC, MP3, M4A and AAC file discovery.
- Title and artist metadata with filename fallback.
- Play / pause, previous / next.
- Shuffle creates a randomized queue without repeating tracks in that queue.
- Visible playback queue; tap a queue item to play it.
- Media3 MediaSessionService for background playback and Android media notification controls.

Build:
1. Install Android Studio (JDK 17 and Android SDK 35).
2. Open this folder in Android Studio.
3. Wait for Gradle Sync to finish and install any requested SDK components.
4. Connect an Android phone (USB debugging enabled) or use an emulator.
5. Press Run.

Choose a folder such as Music/MyPlayer on the phone when the app first opens.
Add/remove files with the phone's file manager, then tap Refresh in the app.

Notes:
- This is a source project, not a prebuilt APK.
- Background playback is implemented with Media3 MediaSessionService. Android's media notification and lock-screen controls depend on notification permission and device settings.
- Actual playback support for FLAC/AAC depends on the Android device's codecs.
- This project has not yet been built or tested on a physical device in this environment.
