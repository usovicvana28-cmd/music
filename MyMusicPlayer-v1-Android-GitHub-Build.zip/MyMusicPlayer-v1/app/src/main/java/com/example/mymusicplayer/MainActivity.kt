package com.example.mymusicplayer

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors

private data class Song(
    val uri: Uri,
    val title: String,
    val artist: String
)

class MainActivity : ComponentActivity() {

    private var mediaController: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    private var songs by mutableStateOf<List<Song>>(emptyList())
    private var queueSongs by mutableStateOf<List<Song>>(emptyList())
    private var selectedFolder by mutableStateOf<Uri?>(null)
    private var currentTitle by mutableStateOf("Выбери папку с музыкой")
    private var currentArtist by mutableStateOf("")
    private var currentUri by mutableStateOf<Uri?>(null)
    private var isPlaying by mutableStateOf(false)
    private var shuffleEnabled by mutableStateOf(false)
    private var status by mutableStateOf("")

    private val prefs by lazy {
        getSharedPreferences("player_settings", MODE_PRIVATE)
    }

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                try {
                    contentResolver.takePersistableUriPermission(uri, flags)
                } catch (_: SecurityException) {
                    // Reading is sufficient for playback; some providers deny write access.
                }
                prefs.edit().putString("music_folder", uri.toString()).apply()
                selectedFolder = uri
                scanFolder(uri)
            }
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        prefs.getString("music_folder", null)?.let { saved ->
            selectedFolder = Uri.parse(saved)
            scanFolder(Uri.parse(saved))
        }

        connectToPlaybackService()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 22.dp, vertical = 28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("MY MUSIC", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(24.dp))

                        Text(
                            currentTitle,
                            style = MaterialTheme.typography.titleLarge,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(currentArtist, style = MaterialTheme.typography.bodyMedium)

                        Spacer(Modifier.height(20.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(onClick = { previousTrack() }) { Text("⏮") }
                            Button(onClick = { playPause() }) {
                                Text(if (isPlaying) "Пауза" else "Играть")
                            }
                            Button(onClick = { nextTrack() }) { Text("⏭") }
                        }

                        TextButton(onClick = { toggleShuffle() }) {
                            Text(
                                if (shuffleEnabled) "🔀 Перемешивание: ВКЛ"
                                else "Перемешивание: ВЫКЛ"
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Библиотека: ${songs.size}")
                            TextButton(onClick = {
                                selectedFolder?.let { scanFolder(it) }
                            }) { Text("Обновить") }
                        }

                        if (selectedFolder == null) {
                            Button(onClick = { folderPicker.launch(null) }) {
                                Text("Выбрать папку с музыкой")
                            }
                            Text(
                                "Создай папку, например Music/MyPlayer, и выбери её.",
                                modifier = Modifier.padding(top = 10.dp),
                                style = MaterialTheme.typography.bodySmall
                            )
                        } else {
                            TextButton(onClick = { folderPicker.launch(selectedFolder) }) {
                                Text("Изменить папку")
                            }
                        }

                        if (status.isNotBlank()) {
                            Text(
                                status,
                                modifier = Modifier.padding(vertical = 4.dp),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Очередь", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${queueSongs.size} треков",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        LazyColumn(modifier = Modifier.fillMaxWidth()) {
                            itemsIndexed(queueSongs) { index, song ->
                                val isCurrent = song.uri == currentUri
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { playSongInQueue(index) }
                                        .padding(vertical = 9.dp)
                                ) {
                                    Text(
                                        (if (isCurrent) "▶  " else "") + song.title,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = if (isCurrent) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.onSurface
                                        }
                                    )
                                    Text(
                                        song.artist,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun connectToPlaybackService() {
        val token = SessionToken(
            this,
            ComponentName(this, PlaybackService::class.java)
        )
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future

        future.addListener({
            try {
                val controller = future.get()
                mediaController = controller
                controller.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(playing: Boolean) {
                        isPlaying = playing
                    }

                    override fun onMediaItemTransition(
                        mediaItem: MediaItem?,
                        reason: Int
                    ) {
                        currentTitle = mediaItem?.mediaMetadata?.title?.toString()
                            ?: "Нет выбранного трека"
                        currentArtist = mediaItem?.mediaMetadata?.artist?.toString().orEmpty()
                        currentUri = mediaItem?.localConfiguration?.uri
                    }
                })
            } catch (_: Exception) {
                status = "Не удалось подключить аудиоплеер."
            }
        }, MoreExecutors.directExecutor())
    }

    private fun scanFolder(uri: Uri) {
        status = "Сканирование папки…"
        val root = DocumentFile.fromTreeUri(this, uri)
        if (root == null || !root.isDirectory) {
            status = "Не удалось открыть папку. Выбери её заново."
            return
        }

        val found = mutableListOf<Song>()

        fun walk(directory: DocumentFile) {
            for (file in directory.listFiles()) {
                if (file.isDirectory) {
                    walk(file)
                } else {
                    val extension = file.name
                        ?.substringAfterLast('.', "")
                        ?.lowercase()
                    if (extension in setOf("flac", "mp3", "m4a", "aac")) {
                        found += readSong(file)
                    }
                }
            }
        }

        try {
            walk(root)
            songs = found.sortedBy { it.title.lowercase() }
            // Keep the existing queue if it is still playing; otherwise seed it from the library.
            val stillAvailable = songs.map { it.uri }.toSet()
            val retained = queueSongs.filter { it.uri in stillAvailable }
            queueSongs = if (retained.isEmpty()) songs else {
                retained + songs.filter { candidate ->
                    retained.none { it.uri == candidate.uri }
                }
            }
            status = if (songs.isEmpty()) {
                "В этой папке пока нет поддерживаемых аудиофайлов."
            } else {
                "Библиотека обновлена."
            }
        } catch (_: Exception) {
            status = "Не удалось прочитать папку. Проверь доступ к ней."
        }
    }

    private fun readSong(file: DocumentFile): Song {
        val fallback = file.name?.substringBeforeLast('.') ?: "Без названия"
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, file.uri)
            val title = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_TITLE
            )?.takeIf { it.isNotBlank() } ?: fallback
            val artist = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_ARTIST
            )?.takeIf { it.isNotBlank() } ?: "Неизвестный исполнитель"
            Song(file.uri, title, artist)
        } catch (_: Exception) {
            Song(file.uri, fallback, "Неизвестный исполнитель")
        } finally {
            retriever.release()
        }
    }

    private fun asMediaItem(song: Song): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .build()
        return MediaItem.Builder()
            .setUri(song.uri)
            .setMediaMetadata(metadata)
            .build()
    }

    private fun playSongInQueue(index: Int) {
        if (index !in queueSongs.indices) return
        startQueueAt(index)
    }

    private fun playSongFromLibrary(song: Song) {
        val newQueue = if (shuffleEnabled) {
            listOf(song) + songs.filter { it.uri != song.uri }.shuffled()
        } else {
            songs
        }
        queueSongs = newQueue
        startQueueAt(newQueue.indexOfFirst { it.uri == song.uri })
    }

    private fun startQueueAt(index: Int) {
        val player = mediaController ?: run {
            status = "Плеер ещё подключается. Попробуй ещё раз через секунду."
            return
        }
        if (index !in queueSongs.indices) return

        player.setMediaItems(queueSongs.map { asMediaItem(it) }, index, 0L)
        player.prepare()
        player.play()
    }

    private fun playPause() {
        val player = mediaController ?: return
        if (player.isPlaying) {
            player.pause()
        } else if (player.mediaItemCount == 0 && songs.isNotEmpty()) {
            playSongFromLibrary(songs.first())
        } else {
            player.play()
        }
    }

    private fun nextTrack() {
        val player = mediaController ?: return
        if (player.mediaItemCount == 0 && songs.isNotEmpty()) {
            playSongFromLibrary(songs.first())
        } else if (player.hasNextMediaItem()) {
            player.seekToNextMediaItem()
        }
        // At the end of the queue playback stops; it does not silently repeat songs.
    }

    private fun previousTrack() {
        val player = mediaController ?: return
        if (player.currentPosition > 3000L) {
            player.seekTo(0L)
        } else if (player.hasPreviousMediaItem()) {
            player.seekToPreviousMediaItem()
        } else if (queueSongs.isNotEmpty()) {
            startQueueAt(0)
        }
    }

    private fun toggleShuffle() {
        shuffleEnabled = !shuffleEnabled
        val player = mediaController ?: return
        if (queueSongs.isEmpty()) {
            queueSongs = if (shuffleEnabled) songs.shuffled() else songs
            return
        }

        val current = player.currentMediaItem?.localConfiguration?.uri
        val currentSong = queueSongs.firstOrNull { it.uri == current }
            ?: songs.firstOrNull { it.uri == current }

        val rest = songs.filter { it.uri != currentSong?.uri }
        val reordered = if (shuffleEnabled) {
            listOfNotNull(currentSong) + rest.shuffled()
        } else {
            listOfNotNull(currentSong) +
                rest.sortedBy { it.title.lowercase() }
        }

        queueSongs = reordered
        if (currentSong != null && player.mediaItemCount > 0) {
            val wasPlaying = player.isPlaying
            val currentIndex = reordered.indexOfFirst { it.uri == currentSong.uri }
            player.setMediaItems(reordered.map { asMediaItem(it) }, currentIndex, 0L)
            player.prepare()
            if (wasPlaying) player.play()
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        mediaController = null
        super.onDestroy()
    }
}
